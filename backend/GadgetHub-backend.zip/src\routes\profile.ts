import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { asyncHandler, validate } from '../lib/http.js';
import { authenticate } from '../middleware/auth.js';
export const profileRouter = Router();
profileRouter.use(authenticate);
profileRouter.patch('/',asyncHandler(async(req,res)=>{const d=validate(z.object({firstName:z.string().min(1).optional(),lastName:z.string().min(1).optional(),phone:z.string().min(7).nullable().optional()}),req.body);res.json(await prisma.user.update({where:{id:req.auth!.userId},data:d,select:{id:true,email:true,phone:true,firstName:true,lastName:true}}));}));
profileRouter.get('/addresses', asyncHandler(async (req, res) => {
  res.json(await prisma.address.findMany({ where: { userId: req.auth!.userId } }));
}));
profileRouter.post('/addresses', asyncHandler(async (req,res) => { const data=validate(z.object({ label:z.string().optional(),recipient:z.string().min(1),phone:z.string().min(7),line1:z.string().min(1),line2:z.string().optional(),city:z.string().min(1),province:z.string().optional(),country:z.string().default('Zimbabwe'),isDefault:z.boolean().default(false) }),req.body); res.status(201).json(await prisma.address.create({data:{...data,userId:req.auth!.userId}})); }));
profileRouter.get('/wishlist', asyncHandler(async(req,res)=>res.json(await prisma.wishlistItem.findMany({where:{userId:req.auth!.userId},include:{product:{include:{images:{take:1}}}}}))));
profileRouter.post('/wishlist/:productId', asyncHandler(async(req,res)=>res.status(201).json(await prisma.wishlistItem.upsert({where:{userId_productId:{userId:req.auth!.userId,productId:String(req.params.productId)}},create:{userId:req.auth!.userId,productId:String(req.params.productId)},update:{}}))));
profileRouter.delete('/wishlist/:productId', asyncHandler(async(req,res)=>{await prisma.wishlistItem.deleteMany({where:{userId:req.auth!.userId,productId:String(req.params.productId)}});res.status(204).send();}));
