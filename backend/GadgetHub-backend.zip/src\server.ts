import { app } from './app.js';
import { config } from './config.js';
import { prisma } from './lib/prisma.js';
const server=app.listen(config.PORT,()=>console.log(`GadgetHub API listening on http://localhost:${config.PORT}/api/v1`));
const shutdown=async()=>{server.close();await prisma.$disconnect();};
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
