import { Router } from 'express';
import { ProductCondition, Role } from '@prisma/client';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { AppError, asyncHandler, validate } from '../lib/http.js';
import { authenticate, authorize } from '../middleware/auth.js';

export const productsRouter = Router();
productsRouter.get('/', asyncHandler(async (req, res) => {
  const q = validate(z.object({ search: z.string().optional(), category: z.string().optional(), brand: z.string().optional(), condition: z.nativeEnum(ProductCondition).optional(), minPrice: z.coerce.number().nonnegative().optional(), maxPrice: z.coerce.number().nonnegative().optional(), sort: z.enum(['newest','price_asc','price_desc','popular']).default('newest'), page: z.coerce.number().int().positive().default(1), limit: z.coerce.number().int().min(1).max(100).default(20) }), req.query);
  const where = { isActive: true, ...(q.search && { OR: [{ name: { contains: q.search, mode: 'insensitive' as const } }, { description: { contains: q.search, mode: 'insensitive' as const } }] }), ...(q.category && { category: { slug: q.category } }), ...(q.brand && { brand: { slug: q.brand } }), ...(q.condition && { condition: q.condition }), ...((q.minPrice !== undefined || q.maxPrice !== undefined) && { price: { gte: q.minPrice, lte: q.maxPrice } }) };
  const orderBy = q.sort === 'price_asc' ? { price: 'asc' as const } : q.sort === 'price_desc' ? { price: 'desc' as const } : q.sort === 'popular' ? { viewCount: 'desc' as const } : { createdAt: 'desc' as const };
  const [items, total] = await prisma.$transaction([prisma.product.findMany({ where, orderBy, skip: (q.page-1)*q.limit, take: q.limit, include: { brand: true, category: true, images: { orderBy: { sortOrder: 'asc' } }, variants: { include: { inventory: true } }, reviews: { where: { approved: true }, select: { rating: true } } } }), prisma.product.count({ where })]);
  res.json({ items, pagination: { page: q.page, limit: q.limit, total, pages: Math.ceil(total/q.limit) } });
}));
productsRouter.get('/:slug', asyncHandler(async (req, res) => {
  const product = await prisma.product.update({ where: { slug: String(req.params.slug) }, data: { viewCount: { increment: 1 } }, include: { brand: true, category: true, images: { orderBy: { sortOrder: 'asc' } }, specifications: true, variants: { include: { inventory: true } }, reviews: { where: { approved: true }, include: { user: { select: { firstName: true, lastName: true } } } } } }).catch(() => null);
  if (!product?.isActive) throw new AppError(404, 'Product not found');
  res.json(product);
}));
const productSchema = z.object({ name: z.string().min(2), slug: z.string().regex(/^[a-z0-9-]+$/), sku: z.string().min(1), reference: z.string().min(1), description: z.string().min(1), price: z.number().positive(), discountPrice: z.number().positive().nullable().optional(), condition: z.nativeEnum(ProductCondition), conditionNotes: z.string().optional(), warrantyMonths: z.number().int().nonnegative().default(0), categoryId: z.string(), brandId: z.string(), featured: z.boolean().default(false) });
productsRouter.post('/', authenticate, authorize(Role.PRODUCT, Role.STORE_MANAGER, Role.SUPER_ADMIN), asyncHandler(async (req, res) => { res.status(201).json(await prisma.product.create({ data: validate(productSchema, req.body) })); }));
productsRouter.patch('/:id', authenticate, authorize(Role.PRODUCT, Role.STORE_MANAGER, Role.SUPER_ADMIN), asyncHandler(async (req, res) => { res.json(await prisma.product.update({ where: { id: String(req.params.id) }, data: validate(productSchema.partial(), req.body) })); }));
productsRouter.delete('/:id', authenticate, authorize(Role.PRODUCT, Role.STORE_MANAGER, Role.SUPER_ADMIN), asyncHandler(async (req, res) => { await prisma.product.update({ where: { id: String(req.params.id) }, data: { isActive: false } }); res.status(204).send(); }));
