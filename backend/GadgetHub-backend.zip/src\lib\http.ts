import type { NextFunction, Request, Response } from 'express';
import { ZodError, type ZodType } from 'zod';

export class AppError extends Error {
  constructor(public status: number, message: string, public details?: unknown) { super(message); }
}
export const asyncHandler = (fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>) =>
  (req: Request, res: Response, next: NextFunction) => void fn(req, res, next).catch(next);
export const validate = <T>(schema: ZodType<T>, data: unknown): T => schema.parse(data);
export function notFound(req: Request, _res: Response, next: NextFunction) { next(new AppError(404, `Route ${req.method} ${req.path} not found`)); }
export function errorHandler(error: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (error instanceof ZodError) return res.status(400).json({ error: 'Validation failed', details: error.issues });
  if (error instanceof AppError) return res.status(error.status).json({ error: error.message, details: error.details });
  console.error(error);
  return res.status(500).json({ error: 'Internal server error' });
}
