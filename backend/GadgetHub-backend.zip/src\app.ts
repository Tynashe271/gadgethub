import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { config } from './config.js';
import { authRouter } from './routes/auth.js';
import { productsRouter } from './routes/products.js';
import { cartRouter } from './routes/cart.js';
import { ordersRouter } from './routes/orders.js';
import { profileRouter } from './routes/profile.js';
import { catalogRouter } from './routes/catalog.js';
import { discoveryRouter } from './routes/discovery.js';
import { servicesRouter } from './routes/services.js';
import { reviewsRouter } from './routes/reviews.js';
import { notificationsRouter } from './routes/notifications.js';
import { loyaltyRouter } from './routes/loyalty.js';
import { commerceRouter } from './routes/commerce.js';
import { contentRouter } from './routes/content.js';
import { authenticityRouter } from './routes/authenticity.js';
import { adminRouter } from './routes/admin.js';
import { errorHandler, notFound } from './lib/http.js';
import {providersRouter} from './routes/providers.js';import {assistantRouter} from './routes/assistant.js';import {webhooksRouter} from './routes/webhooks.js';import {metrics,metricsMiddleware} from './lib/metrics.js';

export const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: config.CORS_ORIGIN.split(',').map(x => x.trim()), credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(morgan(config.NODE_ENV === 'test' ? 'tiny' : 'combined'));
app.use(metricsMiddleware);
app.use('/api', rateLimit({ windowMs: 15*60*1000, limit: 300, standardHeaders: 'draft-8', legacyHeaders: false }));
app.get('/api/v1', (_req, res) => res.json({
  name: 'GadgetHub API',
  version: 'v1',
  status: 'running',
  endpoints: {
    health: '/api/v1/health',
    authentication: '/api/v1/auth',
    products: '/api/v1/products',
    cart: '/api/v1/cart',
    orders: '/api/v1/orders',
    profile: '/api/v1/profile',
    catalog: '/api/v1/catalog', discovery: '/api/v1/discovery', services: '/api/v1/services',
    reviews: '/api/v1/reviews', commerce: '/api/v1/commerce', content: '/api/v1/content', admin: '/api/v1/admin',
  },
}));
app.get('/api/v1/health', (_req,res)=>res.json({status:'ok',timestamp:new Date().toISOString()}));
app.get('/favicon.ico', (_req, res) => res.status(204).send());
app.get('/metrics',(req,res)=>{if(process.env.METRICS_TOKEN&&req.headers.authorization!==`Bearer ${process.env.METRICS_TOKEN}`)return res.status(401).json({error:'Unauthorized'});res.set('Content-Type',metrics.contentType);return metrics.metrics().then(x=>res.send(x));});
app.use('/api/v1/auth', authRouter);
app.use('/api/v1/products', productsRouter);
app.use('/api/v1/cart', cartRouter);
app.use('/api/v1/orders', ordersRouter);
app.use('/api/v1/profile', profileRouter);
app.use('/api/v1/catalog',catalogRouter);
app.use('/api/v1/discovery',discoveryRouter);
app.use('/api/v1/services',servicesRouter);
app.use('/api/v1/reviews',reviewsRouter);
app.use('/api/v1/notifications',notificationsRouter);
app.use('/api/v1/loyalty',loyaltyRouter);
app.use('/api/v1/commerce',commerceRouter);
app.use('/api/v1/content',contentRouter);
app.use('/api/v1/authenticity',authenticityRouter);
app.use('/api/v1/admin',adminRouter);
app.use('/api/v1/providers',providersRouter);
app.use('/api/v1/assistant',assistantRouter);
app.use('/api/v1/webhooks',webhooksRouter);
app.use(notFound);
app.use(errorHandler);
