import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt, { type SignOptions } from 'jsonwebtoken';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { AppError, asyncHandler, validate } from '../lib/http.js';
import { config } from '../config.js';
import { authenticate } from '../middleware/auth.js';
import crypto from 'node:crypto';
import {providerHealth,sendEmail} from '../lib/providers.js';

export const authRouter = Router();
const registerSchema = z.object({ email: z.email(), phone: z.string().min(7).optional(), password: z.string().min(8).max(72), firstName: z.string().min(1), lastName: z.string().min(1) });
const sign = async (id: string, role: string) => {const jti=crypto.randomUUID();await prisma.session.create({data:{id:jti,userId:id,expiresAt:new Date(Date.now()+7*86400000)}});return jwt.sign({ role }, config.JWT_SECRET, { subject: id,jwtid:jti, expiresIn: config.JWT_EXPIRES_IN as SignOptions['expiresIn'] });};

authRouter.get('/', (_req, res) => res.json({
  service: 'Database-backed authentication',
  endpoints: {
    register: { method: 'POST', path: '/api/v1/auth/register' },
    login: { method: 'POST', path: '/api/v1/auth/login' },
    logout: { method: 'POST', path: '/api/v1/auth/logout', authentication: 'Bearer token' },
    currentUser: { method: 'GET', path: '/api/v1/auth/me', authentication: 'Bearer token' },
    forgotPassword: { method: 'POST', path: '/api/v1/auth/forgot-password' },
    resetPassword: { method: 'POST', path: '/api/v1/auth/reset-password' },
  },
  persistence: { users: 'User table', sessions: 'Session table', passwordResets: 'PasswordReset table' },
}));
const postOnly = (endpoint: string) => (_req: import('express').Request, res: import('express').Response) =>
  res.status(405).set('Allow', 'POST').json({ error: 'Method not allowed', message: `Use POST ${endpoint} with a JSON request body` });
authRouter.get('/register', postOnly('/api/v1/auth/register'));
authRouter.get('/login', postOnly('/api/v1/auth/login'));

authRouter.post('/register', asyncHandler(async (req, res) => {
  const data = validate(registerSchema, req.body);
  if (await prisma.user.findFirst({ where: { OR: [{ email: data.email.toLowerCase() }, ...(data.phone ? [{ phone: data.phone }] : [])] } })) throw new AppError(409, 'Email or phone is already registered');
  const {password,...profile}=data;const user = await prisma.user.create({ data: { ...profile, email: profile.email.toLowerCase(), passwordHash: await bcrypt.hash(password, 12) }, select: { id: true, email: true, firstName: true, lastName: true, role: true } });
  res.status(201).json({ user, token: await sign(user.id, user.role) });
}));
authRouter.post('/login', asyncHandler(async (req, res) => {
  const data = validate(z.object({ email: z.email(), password: z.string().min(1) }), req.body);
  const user = await prisma.user.findUnique({ where: { email: data.email.toLowerCase() } });
  if (!user?.isActive || !await bcrypt.compare(data.password, user.passwordHash)) throw new AppError(401, 'Invalid credentials');
  res.json({ user: { id: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName, role: user.role }, token: await sign(user.id, user.role) });
}));
authRouter.post('/logout',authenticate,asyncHandler(async(req,res)=>{await prisma.session.update({where:{id:req.auth!.sessionId},data:{revokedAt:new Date()}});res.status(204).send();}));
authRouter.get('/me', authenticate, asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.auth!.userId }, select: { id: true, email: true, phone: true, firstName: true, lastName: true, role: true, loyaltyPoints: true, createdAt: true } });
  if (!user) throw new AppError(404, 'User not found');
  res.json(user);
}));
authRouter.post('/forgot-password', asyncHandler(async (req,res)=>{
  const {email}=validate(z.object({email:z.email()}),req.body);const user=await prisma.user.findUnique({where:{email:email.toLowerCase()}});
  if(!user)return res.json({message:'If the account exists, reset instructions have been created'});
  const token=crypto.randomBytes(32).toString('hex');await prisma.passwordReset.create({data:{userId:user.id,tokenHash:crypto.createHash('sha256').update(token).digest('hex'),expiresAt:new Date(Date.now()+3600000)}});
  if(providerHealth().email)await sendEmail(user.email,'Reset your GadgetHub password',`Use this link within one hour: ${process.env.APP_BASE_URL}/reset-password?token=${encodeURIComponent(token)}`);
  res.json({message:'If the account exists, reset instructions have been sent'});
}));
authRouter.post('/reset-password',asyncHandler(async(req,res)=>{const d=validate(z.object({token:z.string(),password:z.string().min(8).max(72)}),req.body);const tokenHash=crypto.createHash('sha256').update(d.token).digest('hex');const record=await prisma.passwordReset.findFirst({where:{tokenHash,usedAt:null,expiresAt:{gt:new Date()}}});if(!record)throw new AppError(400,'Invalid or expired reset token');await prisma.$transaction([prisma.user.update({where:{id:record.userId},data:{passwordHash:await bcrypt.hash(d.password,12)}}),prisma.passwordReset.update({where:{id:record.id},data:{usedAt:new Date()}})]);res.json({message:'Password updated'});}));
