import client from 'prom-client';import type{NextFunction,Request,Response}from'express';
client.collectDefaultMetrics();const http=new client.Histogram({name:'http_request_duration_seconds',help:'HTTP request duration',labelNames:['method','route','status'],buckets:[.01,.05,.1,.25,.5,1,2,5]});
export const metricsMiddleware=(q:Request,r:Response,n:NextFunction)=>{const end=http.startTimer();r.on('finish',()=>end({method:q.method,route:q.route?.path??q.path,status:String(r.statusCode)}));n();};export const metrics=client.register;
